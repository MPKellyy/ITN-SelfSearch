Instructions:

* This program only reads JSON files as an input
* To read a file by name only, make sure the JSON file is in the same directory as the JAR file
* If using a JSON file from a different directory, paste full filepath into the software when prompted
* JSON file must be formatted as the example files provided
* Note: The "mapData" entry of the JSON file can be left as "" if map data is not being provided